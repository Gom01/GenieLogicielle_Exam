package AbstractFactory.cars;

public interface CarFactory {

    public Car createCar();
}
