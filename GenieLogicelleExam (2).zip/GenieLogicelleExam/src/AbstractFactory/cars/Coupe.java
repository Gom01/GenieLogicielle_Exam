package AbstractFactory.cars;

public class Coupe extends Car {

	public Coupe() {
		name = "Coupe";
	}
}
