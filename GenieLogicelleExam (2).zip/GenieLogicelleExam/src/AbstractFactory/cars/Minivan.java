package AbstractFactory.cars;

public class Minivan extends Car {

	public Minivan()
	{
		name = "Minivan";
	}
}
