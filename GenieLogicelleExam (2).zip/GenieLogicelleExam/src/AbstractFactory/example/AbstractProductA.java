package AbstractFactory.example;

public interface AbstractProductA {
}
