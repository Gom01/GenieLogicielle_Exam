package AbstractFactory.example;

public interface AbstractProductB {
}
