package AbstractFactory.example;

public class ProductA2 implements AbstractProductA {
}
