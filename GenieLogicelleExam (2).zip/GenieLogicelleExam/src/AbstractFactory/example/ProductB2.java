package AbstractFactory.example;

public class ProductB2 implements AbstractProductB {
}
