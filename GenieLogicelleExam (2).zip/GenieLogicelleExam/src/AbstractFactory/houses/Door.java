package AbstractFactory.houses;


public abstract class Door {

    protected String name;
    protected int price;

    public int getPrice() {
        return price;
    }


}
