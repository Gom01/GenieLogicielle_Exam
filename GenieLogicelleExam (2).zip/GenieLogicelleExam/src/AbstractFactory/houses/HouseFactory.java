package AbstractFactory.houses;

public interface HouseFactory {

    public Wall createWall();
    public Door createDoor();
    public Window createWindow();

}
