package AbstractFactory.houses;

public class WindowWithStructure extends Window {

    public WindowWithStructure() {
        this.name = "Window with Structure";
        this.price = 6;
    }


}
