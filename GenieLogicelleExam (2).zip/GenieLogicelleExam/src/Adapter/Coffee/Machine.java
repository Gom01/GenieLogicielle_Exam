package Adapter.Coffee;

public interface Machine {
	int getNumberOfCapsules();
	boolean isCompletelyUp();
	void stop();
	Engineer getEngineer();
}
