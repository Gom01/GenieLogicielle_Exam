package Adapter.Example;

public class Adaptee {
	public void specificRequest() {
		System.out.println("Specific request");
	}
}
