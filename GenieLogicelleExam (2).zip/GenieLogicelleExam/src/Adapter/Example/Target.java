package Adapter.Example;

public interface Target {
	public void request();
}
