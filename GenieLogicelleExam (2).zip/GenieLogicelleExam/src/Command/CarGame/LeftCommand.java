package Command.CarGame;


public class LeftCommand implements Command {

	public LeftCommand(Car car) {
		this.myCar = car;
	}

	public void execute() {
		myCar.left();
	}

	public void undo() {
		myCar.right();
	}

	private Car myCar;

}
