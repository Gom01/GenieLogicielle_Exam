package Command.Textfile;

public interface Command {
    void execute(TextFile text);
}
