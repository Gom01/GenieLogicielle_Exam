package Command.Textfile;

public class CopyTextFileCommand implements Command {
    @Override
    public void execute(TextFile textFile) {
        textFile.copy();
    }
}
