package Command.Textfile;

public class OpenTextFileCommand implements Command {

    @Override
    public void execute(TextFile textFile) {
        textFile.open();
    }

}
