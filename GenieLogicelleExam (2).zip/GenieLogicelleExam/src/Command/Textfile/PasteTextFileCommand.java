package Command.Textfile;

public class PasteTextFileCommand implements Command {

    @Override
    public void execute(TextFile textFile) {
        textFile.paste();
    }
}
