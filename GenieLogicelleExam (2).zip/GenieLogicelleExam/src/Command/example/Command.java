package Command.example;

public interface Command {
	public void execute();
}
