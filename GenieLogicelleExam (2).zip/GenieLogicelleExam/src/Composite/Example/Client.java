package Composite.Example;

public class Client {
    //         node1
    //         /    \
    //		node2	l3
    //		/  \
    //	   l1  l2

    public static void main(String[] args) {
        Component root = setupTree();
        root.operation();
    }

    public static Component setupTree(){
        //Creating the nodes
        Component node1 = new Composite("Node 1");
        Component node2 = new Composite("Node 2");

        //Creating the leafs.
        Component l1 = new Leaf("Leaf 1");
        Component l2 = new Leaf("Leaf 2");
        Component l3 = new Leaf("Leaf 3");

        //Assigning leaf and nodes to parents (nodes).
        node1.add(node2);
        node1.add(l3);
        node2.add(l1);
        node2.add(l2);

        return  node1;
    }
}
