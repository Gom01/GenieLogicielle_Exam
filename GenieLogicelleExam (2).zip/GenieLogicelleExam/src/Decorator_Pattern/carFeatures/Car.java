package Decorator_Pattern.carFeatures;

public abstract class Car {

    protected String description = "";

    public String getDescription() {
        return this.description;
    }
    
    public abstract int getCost();
    
    public abstract int getSecurityLevel();
    
}
