package Decorator_Pattern.shapes;

public interface Shape {
	void draw();
}
