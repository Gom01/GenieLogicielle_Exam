package Facade.HomeTheater;

public class Client {
    public static void main(String[] args){
        HomeTheraterFacade homeTheraterFacade = new HomeTheraterFacade("amp", "tuner", "player", "projector");

        homeTheraterFacade.watchMovie("Hello");
    }
}
