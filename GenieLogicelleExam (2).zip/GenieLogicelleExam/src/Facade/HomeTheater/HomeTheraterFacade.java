package Facade.HomeTheater;

public class HomeTheraterFacade {
    //String should be class
    String amp;
    String tuner;
    String player;
    String projector;

    public HomeTheraterFacade(String amp, String tuner, String player, String projector) {
        this.amp = amp;
        this.tuner = tuner;
        this.player = player;
        this.projector = projector;
    }

    //methods
    public void watchMovie(String movieName){
        System.out.println("Preparing movie");
        //Uses function of classes
        //tuner.on()
        //player.play()
    }

}
