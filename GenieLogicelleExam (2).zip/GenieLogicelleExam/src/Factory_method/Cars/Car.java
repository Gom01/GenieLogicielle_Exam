package Factory_method.Cars;

abstract public class Car {
	protected String name;
    private String color;

	public String getName() {
        return name;
	}

    public String getColor() {
        return color;
    }

}
