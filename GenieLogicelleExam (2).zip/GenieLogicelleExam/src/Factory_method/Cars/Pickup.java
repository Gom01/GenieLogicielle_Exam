package Factory_method.Cars;

public class Pickup extends Car
{
	public Pickup() {
		this.name = "Pickup";
	}
}
