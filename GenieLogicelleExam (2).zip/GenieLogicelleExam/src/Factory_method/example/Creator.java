package Factory_method.example;

public abstract class Creator {
    abstract public Product factoryMethod();
    public void anOperation(){
        Product product = this.factoryMethod();
        System.out.println("Do something with product " + product.toString());
    }
}
