package Flyweight.Example;

public class UnsharedConcreteFlyweight extends Flyweight {
    private long allState;

    public UnsharedConcreteFlyweight(long allState) {
        super();
        this.allState = allState;
    }

    @Override
    public void operation(long extrinsicState) {
        System.out.println("Unshared Flyweight.Example.Flyweight " + allState +
                " calling operation with extrinsic state " + extrinsicState);
    }
}
