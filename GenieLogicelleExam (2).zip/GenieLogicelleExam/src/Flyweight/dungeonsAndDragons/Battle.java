package Flyweight.dungeonsAndDragons;

import java.util.Random;

public class Battle {
    private static String[] races = {"Elf", "Orc"};
    private static String[] colors = {"green", "red"};
    private static String[] weapons = {"Bow&Arrow", "Axe", "Sword&Shield"};
    private static Random rand = new Random();

    public void start() {
        for (int i = 0; i < 5000; i++) {
            // Get a creature with randomly appearance
            Character creature = CharacterFactory.getCharacter(getRandRace(), getRandColor(), getRandColor(), getRandColor());
            creature.fightWithWeapon(getRandWeapon());
        }

        Character wizard = new Wizard();
        wizard.fightWithWeapon("Magic staff");

        System.out.println("Number of creatures stored: " + CharacterFactory.getCharacterHashMap().keySet().size());
    }

    public static String getRandWeapon() {
        return weapons[rand.nextInt(weapons.length)];
    }

    public static String getRandColor() {
        return colors[rand.nextInt(colors.length)];
    }

    public static String getRandRace() {
        return races[rand.nextInt(races.length)];
    }
}