package Flyweight.dungeonsAndDragons;
public interface Character {
    public abstract void fightWithWeapon(String weapon);
}
