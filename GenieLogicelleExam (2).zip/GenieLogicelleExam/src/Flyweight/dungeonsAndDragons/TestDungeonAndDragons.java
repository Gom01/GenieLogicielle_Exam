package Flyweight.dungeonsAndDragons;

public class TestDungeonAndDragons {
    public static void main(String[] args) {
        Battle battle = new Battle();
        battle.start();
    }
}
