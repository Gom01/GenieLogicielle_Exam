package Flyweight.painting;

public enum BrushSize {
    THIN,
    THICK
}
