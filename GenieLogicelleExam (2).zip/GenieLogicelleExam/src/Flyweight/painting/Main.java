package Flyweight.painting;

public class Main {
    public static void main(String[] args){
        // New thick Red Brush
        Tool redThickBrush1 = ToolFactory.getThickBrush("RED");
        redThickBrush1.draw("I am drawing with my first thick red brush");

        // Red Brush is shared
        Tool redThickBrush2 = ToolFactory.getThickBrush("RED");
        redThickBrush2.draw("I am drawing with my second thick red brush");

        System.out.println("first thick red brush hashcode: " + redThickBrush1.hashCode());
        System.out.println("second thick red brush hashcode : " + redThickBrush2.hashCode());

        System.out.println();
        Tool normalPen = new Pencil();
        normalPen.draw("Bonjour");
        System.out.println();

        // New thin Blue Brush
        Tool blueThinBrush1 = ToolFactory.getThinBrush("BLUE"); //created new pen
        blueThinBrush1.draw("I am drawing with my first thin blue brush");

        // Blue Brush is shared
        Tool blueThinBrush2 = ToolFactory.getThinBrush("BLUE"); //created new pen
        blueThinBrush2.draw("I am drawing with my second thin blue brush");

        System.out.println("first thin blue brush hashcode: " + blueThinBrush1.hashCode());
        System.out.println("second thin blue brush hashcode: " + blueThinBrush2.hashCode());
    }
}
