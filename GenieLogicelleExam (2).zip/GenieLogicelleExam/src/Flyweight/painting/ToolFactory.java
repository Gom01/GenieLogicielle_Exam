package Flyweight.painting;

import java.util.HashMap;

public class ToolFactory {
    private static final HashMap< String, Tool> brushMap = new HashMap<> ();

    public static Tool getThickBrush(String color) {
        String key = color + "-THICK";
        Tool brush = brushMap.get(key);
        if (brush == null) {
            brush = new Brush(color, BrushSize.THICK);
            brushMap.put(key, brush);
        }
        return brush;
    }

    public static Tool getThinBrush(String color) {
        String key = color + "-THIN";
        Tool brush = brushMap.get(key);
        if (brush == null) {
            brush = new Brush(color, BrushSize.THIN);
            brushMap.put(key, brush);
        }
        return brush;
    }

}
