package Memento.Example;

public class TestSimpleMemento {
    public static void main(String[] args){

        Originator originator = new Originator();
        CareTaker careTaker = new CareTaker();

        originator.setState("blue");
        originator.setState("red");
        originator.setState("green");
        careTaker.save(originator.createMemento());
        originator.setState("yellow");
        originator.setState("black");
        careTaker.save(originator.createMemento());
        originator.setState("white");

        careTaker.revert(originator);
        careTaker.revert(originator);
        careTaker.revert(originator);
    }
}
