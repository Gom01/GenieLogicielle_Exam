package Memento.Game;

public class Main {
    public static void main(String[] args){
        Game game = new Game(); // Originator
        CheckpointsManagement checkpointsManagement = new CheckpointsManagement(); // careTaker

        //Create a player
        Player player = new Player(0,0, 0);
        game.setPlayer(player);
        displayPlayerInfos(game);

        // Player moves and gain score +100 score
        game.movePlayerTo(1,1);
        game.increaseScore(100);
        System.out.println("Player moves to (1,1) and gain +100 score");
        displayPlayerInfos(game);


        // Player moves to 2;2 which is a checkpoint
        game.movePlayerTo(2,2);
        checkpointsManagement.save(game.createState());
        System.out.println("Player moves to (2,2). It's a checkpoint and his position and score are saved");
        displayPlayerInfos(game);

        // Player moves to 6;6 and get +100 score
        game.movePlayerTo(6,6);
        game.increaseScore(100);
        System.out.println("Player moves to (6,6). and gain +100 score");
        displayPlayerInfos(game);

        // Player dies
        checkpointsManagement.revert(game);
        System.out.println("Player died! Loading back to previous checkpoint");
        displayPlayerInfos(game);
    }

    public static void displayPlayerInfos(Game game)
    {
        System.out.println("Player position: (" + game.getPlayer().getX() + ","+ game.getPlayer().getY()+")");
        System.out.println("Player score: " + game.getPlayer().getScore());
        System.out.println("");
    }
}
