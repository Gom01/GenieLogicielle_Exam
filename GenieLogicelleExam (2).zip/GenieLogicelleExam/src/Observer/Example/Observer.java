package Observer.Example;

public interface Observer {
    void update();
}
