package Observer.PatientMonitoring;

public interface Observer {
    void update(int position, Problem p, int bloodPressure, int pulseOximetry);
}

