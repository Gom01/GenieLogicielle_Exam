package Observer.PatientMonitoring;

public enum Problem {
    NO_PROBLEM,
    BLOOD_PRESSURE,
    OXIMETRY;
}
