package Proxy.Example;

public interface Subject {
    public void request();
}
