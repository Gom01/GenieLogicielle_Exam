package State.example;

public interface State {
    public void on();
    public void off();
}
