package Strategy.AdventureGame;


public class King extends Character {

    public King() {
        System.out.println("[king]");
        // no weapon by default
    }
}
