package Strategy.Example;

public class Test {
    public static void main(String[] args) {
        Context context = new Context(new ConcreteStrategyA());
        context.doSomeJob();
        context.setCurrentStrategy(new ConcreteStrategyB());
        context.doSomeJob();
    }
}