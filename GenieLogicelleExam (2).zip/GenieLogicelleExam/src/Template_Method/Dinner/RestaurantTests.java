package Template_Method.Dinner;

public class RestaurantTests {

	public static void main(String[] args) {
		Restaurant ilGolossone = new ItalianRestaurant("Il Golossone - Zürich");
		Restaurant leVieuxChalet = new SwissRestaurant("Le Vieux Chalet - Gruyères");
		ilGolossone.prepareDinner();
		leVieuxChalet.prepareDinner();
	}
}
