package chainOfResponsibility.emails;

public class ComplaintHandler extends Handler {

    @Override
    public void forwardMail(Mail mailObj) {
        /*
         * Checking a mail subject and forwarding to next Chain Handler.
         */
        if(mailObj.getSubject().equalsIgnoreCase(COMPLAINT_MAIL)){
            System.out.println("Forwarding Mail to Legal Department.");
        }else{
            this.chain.forwardMail(mailObj);
        }

    }

}