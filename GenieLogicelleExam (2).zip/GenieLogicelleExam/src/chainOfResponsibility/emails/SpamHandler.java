package chainOfResponsibility.emails;

public class SpamHandler extends Handler {

    @Override
    public void forwardMail(Mail mailObj) {
        /*
         * Checking a mail subject and forwarding to next Chain Handler.
         */
        if(mailObj.getSubject().equalsIgnoreCase(SPAM_MAIL)){
            System.out.println("Mail Deleted.");
        }else{
            this.chain.forwardMail(mailObj);
        }
    }

}