package AbstractFactory.cars;

public class CoupeFactory implements CarFactory {

    public Car createCar() {
        return new Coupe();
    }

}
