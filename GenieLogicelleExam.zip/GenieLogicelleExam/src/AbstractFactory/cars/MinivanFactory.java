package AbstractFactory.cars;

public class MinivanFactory implements CarFactory {

    public Car createCar() {
        return new Minivan();
    }

}
