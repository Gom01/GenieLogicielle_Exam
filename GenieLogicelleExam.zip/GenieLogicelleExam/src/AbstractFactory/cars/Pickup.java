package AbstractFactory.cars;

public class Pickup extends Car {

	public Pickup()
	{
		name = "Pickup";
	}
}
