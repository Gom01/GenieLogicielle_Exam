package AbstractFactory.example;

public class ProductA1 implements AbstractProductA {
}
