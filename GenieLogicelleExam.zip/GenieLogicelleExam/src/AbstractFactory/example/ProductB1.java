package AbstractFactory.example;

public class ProductB1 implements AbstractProductB {
}
