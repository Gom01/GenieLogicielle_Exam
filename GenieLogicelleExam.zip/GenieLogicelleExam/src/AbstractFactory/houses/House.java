package AbstractFactory.houses;


public class House {

    private HouseFactory houseFactory;

    private String name = "";

    private Wall southWall;
    private Wall northWall;
    private Wall westWall;
    private Wall eastWall;
    private Window southWindow;
    private Window westWindow;
    private Door eastDoor;

    public House(String name, HouseFactory houseFactory) {
        this.name = name;
        this.houseFactory = houseFactory;
    }

    public void buildHouse() {
        southWall = createWall();
        northWall = createWall();
        westWall = createWall();
        eastWall = createWall();

        southWindow = createWindow(southWall);
        westWindow = createWindow(westWall);

        eastDoor = createDoor(eastWall);

    }

    public void calculatePrice() {
        System.out.println("Total price of " + this.name + " is " + getHousePrice());
    }

    private int getHousePrice() {
        return southWall.getPrice() 
                + westWall.getPrice()
                + northWall.getPrice()
                + eastWall.getPrice()
                + southWindow.getPrice()
                + westWindow.getPrice()
                + eastDoor.getPrice();
    }

    private Wall createWall() {
        return houseFactory.createWall();
    }

    private Door createDoor(Wall w) {
        Door door = houseFactory.createDoor();
        return door;
    }

    private Window createWindow(Wall w) {
        Window window = houseFactory.createWindow();
        return window;
    }
}
