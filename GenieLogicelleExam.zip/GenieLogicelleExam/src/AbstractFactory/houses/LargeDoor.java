package AbstractFactory.houses;

public class LargeDoor extends Door {

    public LargeDoor() {
        this.name = "Large Door";
        this.price = 4;
    }

}
