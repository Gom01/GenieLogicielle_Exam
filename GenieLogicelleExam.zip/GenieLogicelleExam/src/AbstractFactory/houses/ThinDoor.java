package AbstractFactory.houses;

public class ThinDoor extends Door {

    public ThinDoor() {
        this.name = "Thin Door";
        this.price = 2;
    }

}
