package AbstractFactory.houses;

import java.util.ArrayList;

public abstract class Wall {
    protected String name;
    protected int price;

    public int getPrice() {
        return price;
    }
    
}
