package AbstractFactory.houses;


public abstract class Window {

    protected String name;
    protected int price;

    public int getPrice() {
        return price;
    }



}
