package AbstractFactory.houses;

public class WindowToTheFloor extends Window {

    public WindowToTheFloor() {
        this.name = "Window to the Floor";
        this.price = 5;
    }

}
