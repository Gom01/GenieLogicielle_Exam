package AbstractFactory.houses;

public class WoodWall extends Wall {

    public WoodWall()  {
        this.name = "Wood";
        this.price = 15;
    }
}
