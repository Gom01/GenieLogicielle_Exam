package Adapter_Facade.Example;

public class Adaptee {
	public void specificRequest() {
		System.out.println("Specific request");
	}
}
