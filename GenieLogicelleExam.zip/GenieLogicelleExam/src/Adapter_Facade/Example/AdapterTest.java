package Adapter_Facade.Example;

public class AdapterTest {
	public static void main(String[] args) {
		Adaptee adaptee = new Adaptee();
		Target adapter = new Adapter(adaptee);
		adapter.request();
	}
}
