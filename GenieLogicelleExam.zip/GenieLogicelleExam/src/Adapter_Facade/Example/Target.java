package Adapter_Facade.Example;

public interface Target {
	public void request();
}
