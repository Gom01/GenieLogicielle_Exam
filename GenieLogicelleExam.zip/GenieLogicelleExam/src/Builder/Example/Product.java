package Builder.Example;

public class Product {
    private String partA;
    private String partB;
    private String partC;

    public void setPartA(String part) {
        partA = part;
    }

    public void setPartB(String part) {
        partB = part;
    }

    public void setPartC(String part) {
        partC = part;
    }

    @Override
    public String toString() {
        return "Builder.Example.Product{" +
                "partA=" + partA +
                ", partB=" + partB +
                ", partC=" + partC +
                '}';
    }
}
