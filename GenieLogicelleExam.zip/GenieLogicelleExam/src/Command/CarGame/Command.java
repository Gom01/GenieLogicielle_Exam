package Command.CarGame;

public interface Command {
	void execute();
	void undo();
}
