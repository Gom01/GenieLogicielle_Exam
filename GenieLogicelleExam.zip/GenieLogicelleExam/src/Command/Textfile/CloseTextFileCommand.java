package Command.Textfile;

public class CloseTextFileCommand implements Command {

    @Override
    public void execute(TextFile textFile) {
        textFile.close();
    }

}
