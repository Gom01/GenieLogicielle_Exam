package Command.Textfile;

public class Menu {
    private Command[] menuItems = new Command[5];

    public void setCommand(int key, Command command) {
        menuItems[key] = command;
    }

    public void callMenuItem(int key, TextFile textFile) {
        menuItems[key].execute(textFile);
    }

}
