package Command.Textfile;

public class SaveTextFileCommand implements Command {

    @Override
    public void execute(TextFile textFile) {
        textFile.save();
    }

}
