package Command.example;

public class Receiver {
	public void action() {
		System.out.println("Do my action");
	}
}
