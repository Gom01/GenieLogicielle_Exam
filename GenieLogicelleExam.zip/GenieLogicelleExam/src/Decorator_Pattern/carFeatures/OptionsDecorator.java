package Decorator_Pattern.carFeatures;

public abstract class OptionsDecorator extends Car {
    public abstract String getDescription();
}
