package Decorator_Pattern.example;

public interface Component {
    public void operation();
}
