package Decorator_Pattern.example;

public class ConcreteComponent implements Component {
    @Override
    public void operation() {
        System.out.println("Concrete operation");
    }
}
