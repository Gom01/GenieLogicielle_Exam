package Decorator_Pattern.shapes;

public abstract class ShapeDecorator implements Shape {

	protected Shape shape;
	
	public ShapeDecorator(Shape decoratedShape){
		this.shape = decoratedShape;
	}

	@Override
	abstract public void draw();

}
