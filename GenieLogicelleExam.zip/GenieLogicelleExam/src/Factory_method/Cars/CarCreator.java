package Factory_method.Cars;


public abstract class CarCreator {

    public Car orderCar(String color) {
        Car car = createCar();
        return car;
    }

	protected abstract Car createCar();

}
