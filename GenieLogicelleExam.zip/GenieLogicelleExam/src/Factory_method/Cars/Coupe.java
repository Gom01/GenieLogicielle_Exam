package Factory_method.Cars;

public class Coupe extends Car
{
	public Coupe() {
		this.name = "Coupe";
	}
}
