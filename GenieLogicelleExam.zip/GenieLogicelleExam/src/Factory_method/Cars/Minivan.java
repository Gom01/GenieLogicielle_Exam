package Factory_method.Cars;

public class Minivan extends Car
{
	public Minivan() {
		this.name = "Minivan";
	}
}
