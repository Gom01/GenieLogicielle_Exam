package Factory_method.architect;

public class BricksWall extends Wall {
    
    public BricksWall() {
        this.name = "Bricks";
        this.price = 30;
    }

}
