package Factory_method.architect;

public class GlassWall extends Wall {
    public GlassWall() {
        this.name = "Glass";
        this.price = 20;
    }
}
