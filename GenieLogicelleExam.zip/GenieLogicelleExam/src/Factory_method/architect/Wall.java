package Factory_method.architect;

import java.util.ArrayList;
import java.util.List;

public abstract class Wall {
    protected String name;
    protected int price;

    public int getPrice() {
        return price;
    }
}
