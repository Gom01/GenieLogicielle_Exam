package Factory_method.example;

public class ConcreteCreator extends Creator {
    @Override
    public Product factoryMethod() {
        return new ConcreteProduct("Builder.Example.Product");
    }
}
