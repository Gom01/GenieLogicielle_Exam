package Factory_method.example;

public interface Product {
}
