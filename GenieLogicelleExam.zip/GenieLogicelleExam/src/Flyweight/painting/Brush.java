package Flyweight.painting;

public class Brush implements Tool {
    private BrushSize brushSize;
    protected String color;

    public Brush(String color, BrushSize brushSize) {
        this.brushSize = brushSize;
        this.color = color;
    }
    @Override
    public void draw(String content) {
        System.out.println("Drawing '" + content + "' in " + brushSize +  ", color:" + color);
    }
}
