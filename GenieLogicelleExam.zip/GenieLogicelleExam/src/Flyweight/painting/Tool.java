package Flyweight.painting;

public interface Tool {
    void draw(String content);
}
