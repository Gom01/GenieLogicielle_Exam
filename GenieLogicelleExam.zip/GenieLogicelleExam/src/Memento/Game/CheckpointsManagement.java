package Memento.Game;
import java.util.Stack;

public class CheckpointsManagement {
    Stack<Game.GameState> states = new Stack<>();

    public void save(Game.GameState state) {
        states.push(state);
    }

    public void revert(Game game) {
        if (!states.isEmpty())
            game.restore(states.pop());
        else
            System.out.println("Cannot undo !");
    }
}
