package Observer.Clock;

public interface ClockTimer {
    int getHour();
    int getMinute();
    int getSecond();
    void tick();
}