package Observer.Clock;

public class Main {


    public static void main(String[] args) {
        MyTimer clockTimer = new MyTimer();

        new AnalogClock(clockTimer);
        new DigitalClock(clockTimer);
    }
}