package Observer.Example;

public class ConcreteObserver implements Observer {
    ConcreteSubject subject;
    public ConcreteObserver(ConcreteSubject subject) {
        this.subject = subject;
        subject.registerObserver(this);
    }
    @Override
    public void update() {
        //When something is happening
        System.out.println("Observer was notified: subject has state: " +
                this.subject.getState());
    }
}