package Observer.Example;

import java.util.ArrayList;
import java.util.List;

public class ConcreteSubject implements Subject {
    private List<Observer> observers = new
            ArrayList<Observer>();
    int state = 0;
    @Override
    public void registerObserver(Observer o) {
        observers.add(o);
    }
    @Override
    public void removeObserver(Observer o) {
        observers.remove(o);
    }
    @Override
    public void notifyObservers() {
        for (Observer o : observers)
            o.update();
    }
    public void setState(int state) {
        //Function to modify
        this.state = state;
        if (state > 100)
            this.notifyObservers();
    }
    public int getState() {
        return state;
    }
}