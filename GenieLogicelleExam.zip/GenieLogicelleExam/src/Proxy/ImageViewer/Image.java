package Proxy.ImageViewer;

public interface Image {
    public void showImage(User user);
}
