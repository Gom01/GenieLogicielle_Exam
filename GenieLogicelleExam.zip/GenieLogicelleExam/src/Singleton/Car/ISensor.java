package Singleton.Car;

public interface ISensor {
    public String getDescription();
}
