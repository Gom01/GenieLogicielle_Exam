package Strategy.AdventureGame;


public class BowAndArrowBehavior implements WeaponBehavior {
    
    public void useWeapon() {
        System.out.println("use Bow and arrows");
    }
}
