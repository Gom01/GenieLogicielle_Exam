package Strategy.AdventureGame;


public class Queen extends Character {
    
    public Queen() {
        System.out.println("[character.Queen]");
        // no weapon by default
    }
}
