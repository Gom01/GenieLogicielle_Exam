package Strategy.AdventureGame;

public class Troll extends Character {
    
    public Troll() {
        System.out.println("[character.Troll]");
        this.setWeapon(new AxeBehavior());
    }
}
