package Strategy.AdventureGame;

public interface WeaponBehavior {
    void useWeapon();
}
