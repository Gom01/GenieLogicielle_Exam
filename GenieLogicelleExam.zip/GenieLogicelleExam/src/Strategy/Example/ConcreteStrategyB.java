package Strategy.Example;

public class ConcreteStrategyB implements Strategy {
    @Override
    public void algorithm() {
        System.out.println("do some job");
        System.out.println("Very nice concrete strategy B");
    }
}