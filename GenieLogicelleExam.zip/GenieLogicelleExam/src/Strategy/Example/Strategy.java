package Strategy.Example;

public interface Strategy {
    public void algorithm();
}
