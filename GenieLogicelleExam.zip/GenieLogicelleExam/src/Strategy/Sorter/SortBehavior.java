package Strategy.Sorter;

public interface SortBehavior {
    void sort(int[] vector);
}
