package chainOfResponsibility.Example;

public class Client {
    public static void main(String[] args) {
        Handler firstHandler = new ConcreteHandler1();
        Handler secondHandler = new ConcreteHandler2();
        Handler thirdHandler = new ConcreteHandler3();

        firstHandler.setSuccessor(secondHandler);
        secondHandler.setSuccessor(thirdHandler);

        Request request = new Request("dog");
        firstHandler.handleRequest(request);

        request = new Request("House");
        firstHandler.handleRequest(request);
    }
}