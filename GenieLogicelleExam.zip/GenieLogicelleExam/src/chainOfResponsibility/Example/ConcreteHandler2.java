package chainOfResponsibility.Example;

import java.util.Arrays;
import java.util.List;

public class ConcreteHandler2 extends Handler {
    List<String> myColors = Arrays.asList("red", "green", "blue", "yellow");

    @Override
    public void handleRequest(Request request) {
        if (myColors.contains(request.getValue()))
            System.out.println("chainOfResponsibility.Example.Request handled for " + request.getValue() + "by " + this);
        else
            successor.handleRequest(request);
    }
}
