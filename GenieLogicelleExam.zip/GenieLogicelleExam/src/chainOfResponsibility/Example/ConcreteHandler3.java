package chainOfResponsibility.Example;

import java.util.Arrays;
import java.util.List;

public class ConcreteHandler3 extends Handler{
    List<String> myNumbers = Arrays.asList("100", "20", "5", "7");
    @Override
    public void handleRequest(Request request) {
        if (myNumbers.contains(request.getValue().toString()))
            System.out.println("chainOfResponsibility.Example.Request handled for " + request.getValue() + "by " + this);
        else
            throw new RuntimeException("chainOfResponsibility.Example.Request could not be handled.");
    }
}
