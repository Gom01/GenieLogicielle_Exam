package chainOfResponsibility.emails;

public class FanHandler extends Handler {

    @Override
    public void forwardMail(Mail mailObj) {
        /*
         * Checking a mail subject and forwarding to next Chain Handler.
         */
        if(mailObj.getSubject().equalsIgnoreCase(FAN_MAIL)){
            System.out.println("Forwarding Mail to CEO.");
        }else{
            this.chain.forwardMail(mailObj);
        }

    }


}
