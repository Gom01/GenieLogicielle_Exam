package chainOfResponsibility.emails;

public abstract class Handler {

    protected Handler chain;

    String SPAM_MAIL="SPAM_MAIL";
    String FAN_MAIL="FAN_MAIL";
    String COMPLAINT_MAIL="COMPLAINT_MAIL";
    String NEW_LOC_MAIL="NEW_LOC_MAIL";

    public void setNextChain(Handler nextChain) {
        this.chain=nextChain;
    }

    abstract void forwardMail(Mail mailObj);
}
