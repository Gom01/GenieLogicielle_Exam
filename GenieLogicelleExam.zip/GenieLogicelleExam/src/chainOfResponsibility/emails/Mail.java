package chainOfResponsibility.emails;

public class Mail {

    private String subject;

    public Mail(String subject) {
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

}