package chainOfResponsibility.emails;

public class NewLocHandler extends Handler {

    @Override
    public void forwardMail(Mail mailObj) {
        /*
         * Checking a mail subject.
         */
        if(mailObj.getSubject().equalsIgnoreCase(NEW_LOC_MAIL)){
            System.out.println("Forwarding Mail to Business Development Group.");
        }else{
            this.chain.forwardMail(mailObj);
        }

    }
}